<html>
<title> Ejemplo simple de arreglos  </title>
<body>
<?PHP
  // Inicializacion del Vector

  $dia[0] = "Domingo";
  $dia[1] = "Lunes";
  $dia[2] = "Martes";
  $dia[3] = "Mi�rcoles";
  $dia[4] = "Jueves";
  $dia[5] = "Viernes";
  $dia[6] = "S�bado";

  // Impresion del vector

  for($i=0; $i<7; $i++)
   {
    echo ($dia[$i] . "<Br>") ;
   }
 ?>
</body>
</html>

