<html>
<title>  Uso de arreglos  </title>
<body>
<?PHP
  // Inicializacion del arreglo

  $Empleado[0] = 4371;
  $Empleado[1] = "Martinez Leandro";
  $Empleado[2] = "27.643.742";
  $Empleado[3] = 1429.54;
  $Empleado[4] = "Arquitecto";

  // Impresion del arreglo

  echo ("Grupo: " . $Empleado[0] . "<Br>");
  echo ("Nombre: " . $Empleado[1] . "<Br>");
  echo ("Clave : " . $Empleado[2] . "<Br>");
  echo ("Sueldo: " . $Empleado[3] . "<Br>");
  echo ("Profesion: " . $Empleado[4] . "<Br>");
 ?>

</body>



