<Html>
<Title>  Uso de count </Title>
<Body>
<?PHP
  // Inicializacion del arreglo

  $Articulos =array("L�pis","Goma","Hoja","Tinta");

  // Impresion del numero de elementos del arreglo

  $Cantidad = count($Articulos);
  echo ("La cantidad de Art�culos son: " . $Cantidad);

 ?>
</Body>
</Html>

