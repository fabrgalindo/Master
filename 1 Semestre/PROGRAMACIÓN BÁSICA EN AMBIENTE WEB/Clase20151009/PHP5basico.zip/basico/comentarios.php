<HTML>
 <HEAD>
   <TITLE>Funciones para Variables</TITLE>
 </HEAD>
 <BODY>
   <CENTER>
     <H2>Usando comentarios</H2>
 	<?php
 		echo 'comentarios con PHP <br>';
 		echo "Tipos de comentarios"; // Una l�nea
 	// comentario inicial

        # Comentario tipo shell de unix
        /* Comentario

          de bloque*/

 ?>

   </CENTER>
 </BODY>
</HTML>
