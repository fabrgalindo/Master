<HTML>
 <HEAD>
   <TITLE>Funciones para Variables</TITLE>
 </HEAD>
 <BODY>
   <CENTER>
     <H2>Usando isset(), unset() y empty()</H2>
     <?php
       $cadena; //definimos la variable pero no la inicializamos.
       echo '$cadena ';
       echo (isset($cadena))?'est� ':'no est� ';
       echo "inicializada<BR>";
       echo (empty($cadena))?'$cadena est� vac�a':$cadena;
       echo "<BR><BR>";
       $cadena="";
       echo '$cadena ';
       echo (isset($cadena))?'est� ':'no est� ';
       echo "inicializada<BR>";
       echo (empty($cadena))?'$cadena est� vac�a':$cadena;
       echo "<BR><BR>";
       $cadena="3.1416 es el valor de PI";
       echo '$cadena ';
       echo (isset($cadena))?'est� ':'no est� ';
       echo "inicializada<BR>";
       echo (empty($cadena))?'$cadena est� vac�a':$cadena;
       echo "<BR><BR>";
       unset($cadena);
       echo '$cadena ';
       echo (isset($cadena))?'est� ':'no est� ';
       echo "inicializada<BR>";
       echo (empty($cadena))?'$cadena est� vac�a':$cadena;
     ?>
   </CENTER>
 </BODY>
</HTML>
