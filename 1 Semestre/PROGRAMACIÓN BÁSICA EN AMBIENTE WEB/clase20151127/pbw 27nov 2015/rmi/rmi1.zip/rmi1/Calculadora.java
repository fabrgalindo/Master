
/**
 * Interfaz remoto 
 */
public interface Calculadora extends java.rmi.Remote {
    int sumar(int a, int b) throws java.rmi.RemoteException;
    int restar(int a, int b) throws java.rmi.RemoteException;
    int multiplicar(int a, int b) throws java.rmi.RemoteException;
    int dividir(int a, int b) throws java.rmi.RemoteException;
    int  getContadorPeticiones() throws java.rmi.RemoteException;
}
