
import java.rmi.Naming;
import java.rmi.RMISecurityManager;

/**
 * Ejemplo de cliente para la calculadora remota RMI
 * @author ribadas
 */
public class EjemploCliente {
    public static void main(String[] args) {
        if (args.length != 1) {
	    System.out.println("Error: sintaxis incorrecta. USO: java EjemploCliente host");
	    System.exit(0);
        }
        
        try {
            String host = args[0];
            
            // Establecer gestor de seguridad 
	    // En este caso no es necesario: no se descargan bytecodes de localizaciones remotas
	    // System.setSecurityManager(new RMISecurityManager());
            
            // Obtiene el stub del rmiregistry
            Calculadora calcStub = (Calculadora) Naming.lookup("rmi://"+host+"/Calculadora");
            
            // Llamdas remotas
            System.out.println("Suma  30 + 5 = " + calcStub.sumar(30, 5));
            //calcStub.incrementarContadorPeticiones();
            System.out.println("Resta  30 - 5 = " + calcStub.restar(30, 5));
            //calcStub.incrementarContadorPeticiones();
            System.out.println("Multiplica  30 * 5 = " + calcStub.multiplicar(30, 5));
            //calcStub.incrementarContadorPeticiones();
            System.out.println("Divide  30 / 5 = " + calcStub.dividir(30, 5));
            //calcStub.incrementarContadorPeticiones();
            System.out.println("Contador peticiones: " + calcStub.getContadorPeticiones());
        } catch (Exception e) {
            System.out.println("Error: " + e);
        }
    }
}
