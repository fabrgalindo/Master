
import java.rmi.RemoteException;

/**
 * Implementación del interfaz remoto Calculadora sin heredar de UnicastRemoteObject
 * @author ribadas
 */
public class CalculadoraImpl2  implements Calculadora{

    private int contadorPeticiones;
    
    public CalculadoraImpl2()  {
        contadorPeticiones = 0;    
    }

    public int sumar(int a, int b) throws RemoteException {
        contadorPeticiones++;
        System.out.println("SERVIDOR: suma "+a+"+"+b);
        
        return(a+b);
    }

    public int restar(int a, int b) throws RemoteException {
        contadorPeticiones++;
        System.out.println("SERVIDOR: resta "+a+"+"+b);
        
        return(a-b);
    }

    public int multiplicar(int a, int b) throws RemoteException {
        contadorPeticiones++;
        System.out.println("SERVIDOR: multiplica "+a+"+"+b);
        
        return(a*b);
    }

    public int dividir(int a, int b) throws RemoteException {
        contadorPeticiones++;
        System.out.println("SERVIDOR: divide "+a+"+"+b);
        
        return(a/b);
    }

    public int getContadorPeticiones() throws RemoteException {
        return (contadorPeticiones);
    }
}