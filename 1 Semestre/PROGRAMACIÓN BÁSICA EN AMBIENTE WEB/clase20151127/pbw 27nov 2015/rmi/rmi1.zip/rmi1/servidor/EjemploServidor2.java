
import java.rmi.Naming;
import java.rmi.server.UnicastRemoteObject;

/**
 * Ejemplo de servidor usando la implementación de Caluladora remota
 * que no hereda de UnicastRemoteObject
 * => El servidor debe exportar el objeto remoto explicitamente
 * @author ribadas
 */
public class EjemploServidor2 {
public static void main(String[] args){
        try {
            System.out.println("Servidor crea calculadora remota");
            Calculadora calc = new CalculadoraImpl2();
            
            System.out.println("Servidor exporta calculadora remota");
            Calculadora calcStub = (Calculadora) UnicastRemoteObject.exportObject(calc, 0);
             
            System.out.println("Servidor registra calculadora remota");
            Naming.rebind("rmi://localhost/Calculadora", calcStub);
            
             System.out.println("Servidor entra en espera ... ");
        } catch (Exception e) {
            System.out.println("Error en servidor:"+e);
        }
}
}
