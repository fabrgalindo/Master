
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

/**
 * Implementación del interfaz remoto Calculadora heredando d UnicastRemoteObject
 * @author ribadas
 */
public class CalculadoraImpl extends UnicastRemoteObject implements Calculadora{

    private int contadorPeticiones;
    
    public CalculadoraImpl() throws RemoteException {
        super();   // Llamada al constructor de UnicastRemoteObject 
                   // para que el objeto  se exporte a si mismo
        contadorPeticiones = 0;    
    }

    public int sumar(int a, int b) throws RemoteException {
        contadorPeticiones++;
        System.out.println("SERVIDOR: suma "+a+"+"+b);
        
        return(a+b);
    }

    public int restar(int a, int b) throws RemoteException {
        contadorPeticiones++;
        System.out.println("SERVIDOR: resta "+a+"+"+b);
        
        return(a-b);
    }

    public int multiplicar(int a, int b) throws RemoteException {
        contadorPeticiones++;
        System.out.println("SERVIDOR: multiplica "+a+"+"+b);
        
        return(a*b);
    }

    public int dividir(int a, int b) throws RemoteException {
        contadorPeticiones++;
        System.out.println("SERVIDOR: divide "+a+"+"+b);
        
        return(a/b);
    }

    public int getContadorPeticiones() throws RemoteException {
        return (contadorPeticiones);
    }

}
