
import java.rmi.Naming;

/**
 * Ejemplo de servidor usando la implementación de Caluladora remota
 * que hereda de UnicastRemoteObject => no hay que exportarlo
 * @author ribadas
 */
public class EjemploServidor {
public static void main(String[] args){
        try {
            System.out.println("Servidor crea calculadora remota");
            Calculadora calcStub = new CalculadoraImpl();
                         
            System.out.println("Servidor registra calculadora remota");
            Naming.rebind("rmi://localhost/Calculadora", calcStub);
            
            System.out.println("Servidor entra en espera ... ");             
        } catch (Exception e) {
            System.out.println("Error en servidor:"+e);
        }
}
}
